(* ::Package:: *)

Needs["YuK`"]


(*SetOptions[$FrontEnd,
	CaseSensitiveCommandCompletion->True]*)


(*SetOptions[$FrontEndSession,
	CodeAssistOptions->{"FloatingElementEnable"->False}]*)

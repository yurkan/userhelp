The structure of the packages is made to work in a "portable" mode.
There is no need to put the packages in the $UserBaseDirectory directory.
Launch the file install.nb, select all cells (CTRL-A) and evaluate (SHIFT-ENTER).
This saves the path to the package directory in the Wolfram $UserBaseDirectory.

Look for (F1) the tutorial "Building User Help Pages" 
that describes how to create and to edit user help pages.

P.S. There are additional menu commands set in the directory 
"Autoload" that might be commented out.

Yuri E. Kandrashkin

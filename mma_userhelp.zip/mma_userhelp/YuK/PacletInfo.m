Paclet[
	Name -> "YuK",
	Version -> "0.0",
	MathematicaVersion -> "11.0.0",
	Extensions -> {
		{"Kernel",
			"Context" -> 
				{"YuK`",
				"YuK`Common`",
				"YuK`System`"}
		},
		{"Documentation",
			Language -> "English",
			LinkBase -> "YuK",
			Resources -> 
				{"ReferencePages/Symbols/$YuKDirectory"}
		}
	}]
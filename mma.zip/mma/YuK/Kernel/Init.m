(* ::Package:: *)

(* initialization file for the package YuK` *)


BeginPackage["YuK`"]
$YuKDirectory::usage = "$YuKDirectory is a base directory of the package YuK`"
$YuKDirectory = DirectoryName[$InputFileName,3]
SetAttributes[$YuKDirectory, {Protected, Locked}]
EndPackage[]


(* ::Text:: *)
(*Seeting the default directory and paclet paths*)


With[
	{yukDir=YuK`$YuKDirectory,
	toolsDir=FileNameJoin[{YuK`$YuKDirectory,"Tools"}]},
	If[!MemberQ[$Path,yukDir],
		PacletManager`PacletDirectoryAdd[toolsDir];
		PrependTo[$Path,toolsDir];
		PacletManager`PacletDirectoryAdd[yukDir];
		PrependTo[$Path,yukDir]]];


(* ::Text:: *)
(*Launch autoload files*)


Module[{dirs},
	dirs = FileNameJoin[{YuK`$YuKDirectory, "Autoload"}];
	dirs = FileNames["*", dirs, 1];
	dirs = SortBy[dirs, FileBaseName /@ dirs];
	Scan[Get, FileNames["Init.m", dirs, Infinity]]]

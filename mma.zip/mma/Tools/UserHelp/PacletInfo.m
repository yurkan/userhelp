Paclet[
	Name -> "UserHelp",
	Version -> "0.0",
	MathematicaVersion -> "11.0.0",
	Extensions -> {
		{"Kernel",
			"Context" -> 
				{"UserHelp`Pages`"}
		},
		{"Documentation",
			Language -> "English",
			LinkBase -> "UserHelp",
			Resources -> 
				{"ReferencePages/Symbols/BuildHelpPages",
				"ReferencePages/Symbols/HelpPageToggle",
				"ReferencePages/Symbols/SuggestReferences",
				"ReferencePages/Symbols/SymbolInformation",
				"ReferencePages/Symbols/UserHelpLookup",
				"ReferencePages/Symbols/UserHelpPage",
				"Tutorials/BuildingUserHelpPages",
				"Guides/PackageUserHelpGuide",
				"Guides/UserHelpPageMenu"}
		}
	}]
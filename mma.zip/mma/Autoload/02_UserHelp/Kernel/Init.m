(* ::Package:: *)

Needs/@{"YuK`","UserHelp`"}


FrontEndExecute[
	FrontEnd`AddMenuCommands[
		FrontEnd`SelectionHelpDialog,
		{MenuItem["Create Help Page",
			FrontEnd`KernelExecute[{
				Needs["UserHelp`"],
				UserHelpPage[NotebookRead[SelectedNotebook[]]]}],
		System`MenuEvaluator->Automatic]}]]


FrontEndExecute[
	FrontEnd`AddMenuCommands[
		FrontEnd`SelectionHelpDialog,
		{MenuItem["Edit &Documentation Page",
			FrontEnd`KernelExecute[{
				Needs["UserHelp`"],
				HelpPageToggle[]}],
			MenuKey["F1",Modifiers->{"Shift"}],
		System`MenuEvaluator->Automatic]}]]


FrontEndExecute[
	FrontEnd`AddMenuCommands[
		FrontEnd`SelectionHelpDialog,
		{MenuItem["Selected &Function Page",
			FrontEnd`KernelExecute[{
				Needs["UserHelp`"],
				UserHelpLookup[]}],
			MenuKey["F1",Modifiers->{"Control"}],
		System`MenuEvaluator->Automatic]}]]


With[
	{solDir=FileNameJoin[{YuK`$YuKDirectory,"Solutions"}]},
	If[!MemberQ[$Path,solDir],
			PacletManager`PacletDirectoryAdd[solDir];
			PrependTo[$Path,solDir]]];

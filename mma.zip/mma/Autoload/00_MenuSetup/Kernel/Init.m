(* ::Package:: *)

FrontEndExecute[FrontEnd`ResetMenusPacket[{Automatic}]]


FrontEndExecute[FrontEnd`AddMenuCommands["FindEvaluatingCell",
  {MenuItem["Kernel Quit Command",
	FrontEndExecute[{FrontEnd`FrontEndToken["EvaluatorQuit"]}],
    MenuKey["q", Modifiers -> {"Control"}]]}]];


FrontEndExecute[FrontEnd`AddMenuCommands["Close",
  {MenuItem["Close",
	FrontEndExecute[
		{FrontEnd`FrontEndToken["AllWindowsFront"],
		FrontEnd`FrontEndToken["Close"]}],
    MenuKey["w", Modifiers -> {"Control"}]]}]];


FrontEndExecute[FrontEnd`AddMenuCommands["InitializationGroup",
  {MenuItem["Initialization Command",
	InitializationCell->Toggle,
    MenuKey["]", Modifiers -> {"Control","Command"}]]}]];


FrontEndExecute[FrontEnd`AddMenuCommands["MenuListPalettesMenu",
{
MenuItem["Clear Cell Labels and Change Times",
	FrontEnd`KernelExecute[{
		NotebookFind[SelectedNotebook[],"Input",All,CellStyle],
		FrontEndExecute[{
			FrontEnd`RemoveOptions[FrontEnd`SelectionObject,"CellChangeTimes"]}],
			SetOptions[NotebookSelection[SelectedNotebook[]],CellLabel->""]}]],

MenuItem["Compare Notebooks",
	FrontEnd`KernelExecute[
		NotebookOpen[
			ToFileName[{$InstallationDirectory,"AddOns","Applications",
				"AuthorTools","FrontEnd","TextResources"},"NotebookDiff.nb"]]]],
Delimiter}]]


FrontEndExecute[FrontEnd`AddMenuCommands["Balance",
{
MenuItem["Square Brakets",
	FrontEndExecute[{
		FrontEnd`NotebookWrite[FrontEnd`InputNotebook[], "\[LeftDoubleBracket]", After],
		FrontEnd`NotebookWrite[FrontEnd`InputNotebook[], "\[RightDoubleBracket]", Before]}],
	MenuKey["[", Modifiers -> {"Command"}]]
}]]

(* ::Package:: *)

BeginPackage["UserHelp`"]
EndPackage[]


Scan[
	Needs["UserHelp`"<>#]&,
		{"Common`", "Information`","Build`","Pages`"}];


(*FrontEndExecute[
{FrontEnd`AddMenuCommands["MenuListPalettesMenu",
{MenuItem["Reference Link",
	FrontEnd`KernelExecute[
		{(*Needs["UserHelp`"],*)
		Symbol["UserHelp`ReferenceMaker`PacletLink"][]}],
	MenuKey["h",Modifiers->{"Control"}],
	System`MenuEvaluator->Automatic],
Delimiter}]}]*)
